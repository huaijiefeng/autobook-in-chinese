typedef int nly;
