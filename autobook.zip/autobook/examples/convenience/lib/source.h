extern void foo	(double argument);
