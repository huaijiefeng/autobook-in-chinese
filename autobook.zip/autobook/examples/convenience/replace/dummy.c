/* This declaration ensures that we don't try to create an empty library.  */
typedef int dummy;
